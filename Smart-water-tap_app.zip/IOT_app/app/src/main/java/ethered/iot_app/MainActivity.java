package ethered.iot_app;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import com.ubidots.ApiClient;
import com.ubidots.Variable;
import android.widget.Switch;

public class MainActivity extends AppCompatActivity {


    private Button settimer;
    private TextView displaytime;



    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //simpleSwitch1 = (Switch) findViewById(R.id.simpleSwitch1);
        TimePicker simpleTimePicker = (TimePicker)findViewById(R.id.simpleTimePicker); // initiate a time

        settimer = (Button)findViewById(R.id.settime);
        int hours =simpleTimePicker.getHour();
        int minutes=simpleTimePicker.getMinute();
        settimer.setEnabled(true);

        simpleTimePicker.setIs24HourView(true); // set 24 hours mode for the time picker
        settimer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Integer apitime = getcurrenttime();
                new ApiUbidots2().execute(apitime);
                new ApiUbidots3().execute(1);
            }
        });




    }
    public class ApiUbidots3 extends AsyncTask<Integer, Void, Void> {
        private final String API_KEY = "A1E-24300502f9e73f8e5c0b147ad";/*Add your api key*/
        private final String VARIABLE_ID = "5bd2ba011cf84e";/*Add your vaariable id*/

        @Override
        protected Void doInBackground(Integer... params) {
            ApiClient apiClient = new ApiClient(API_KEY);
            Variable batteryLevel = apiClient.getVariable(VARIABLE_ID);

            batteryLevel.saveValue(params[0]);
            return null;
        }


    }


    public class ApiUbidots2 extends AsyncTask<Integer, Void, Void> {
        private final String API_KEY = "A1E-24300502f5c0b147ad";/*Add your api key*/
        private final String VARIABLE_ID = "5bd29ef745461";/*Add your vaariable id*/

        @Override
        protected Void doInBackground(Integer... params) {
            ApiClient apiClient = new ApiClient(API_KEY);
            Variable batteryLevel = apiClient.getVariable(VARIABLE_ID);

            batteryLevel.saveValue(params[0]);
            return null;
        }


    }
    Integer getcurrenttime(){
        TimePicker simpleTimePicker = (TimePicker)findViewById(R.id.simpleTimePicker);
        simpleTimePicker.setIs24HourView(true); // set 24 hours mode for the time picker
        int hours = 0;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            hours = simpleTimePicker.getHour();
        }
        int minutes= 0;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            minutes = simpleTimePicker.getMinute();
        }

        String hrtostr="";
        String mintostr="";
        if(hours<10)
        {
            hrtostr="0"+Integer.toString(hours);
        }
        else
            {
                hrtostr=Integer.toString(hours);
            }

        if(minutes<10)
        {
            mintostr="0"+Integer.toString(minutes);
        }
        else {
            mintostr = Integer.toString(minutes);
        }
        String value = (hrtostr+ mintostr);

        Toast.makeText(MainActivity.this, "Water will start filling at: "+hrtostr+":"+mintostr,Toast.LENGTH_LONG).show();
        Integer value2 = Integer.parseInt(value);
        return value2;
    }


}